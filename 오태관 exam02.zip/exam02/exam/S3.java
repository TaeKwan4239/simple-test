package exam;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class S3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner=new Scanner(System.in);
		
		int n = scanner.nextInt();
		
		List<Integer> numbers = new ArrayList<>();
        for (int i = 1; i <= n; i++) {
            numbers.add(i);
        }
        Collections.shuffle(numbers);  
        for (int num : numbers) {
            System.out.print(num + " ");
        }
        System.out.println();
        Collections.sort(numbers);
        for (int num : numbers) {
            System.out.print(num + " ");
        }
        scanner.close();
        
	}

}
