package egovframework.example.exam4;

public class A {
// 1) 이론 풀이 : 주석으로 풀이
	/*
	 * 디자인 패턴은 웹 애플리케이션 개발에서 역할 분리를 명확히 하기 위해 사용되는 구조입니다. 이 패턴은 전통적인
	 * Model-View-Controller 패턴을 기반으로 스프링 프레임워크에 맞게 구현한 것입니다. model: 데이터와 비즈니스 로직을
	 * 처리한다 view: 사용자에게 보여지는 화면 처리이다 controller: 사용자 요청을 받고, 처리 후 모델과 뷰를 연결한다
	 */

}
