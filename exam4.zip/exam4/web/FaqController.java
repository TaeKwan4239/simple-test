/**
 * 
 */
package egovframework.example.exam4.web;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;

import egovframework.example.common.Criteria;
import egovframework.example.exam4.service.FaqService;

/**
 * @author user
 *
 */
@Controller
public class FaqController {
//	서비스 가져오기
	@Autowired
	private FaqService faqService;
	
//	전체조회
	@GetMapping("/faq/faq.do")
	public String selectFaqList(@ModelAttribute Criteria criteria, Model model) {
		
		List<?> list = faqService.selectFaqList(criteria);
		
		model.addAttribute("list", list);
		return "faq/faq_all";
	}
}
